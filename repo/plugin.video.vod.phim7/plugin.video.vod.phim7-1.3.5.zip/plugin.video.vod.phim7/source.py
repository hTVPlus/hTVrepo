# -*- coding: utf-8 -*-

import re
import json
import api


class Source:
	def __init__(self, cache_path):
		self.cache_path = cache_path
		self.base_url = 'http://www.phim7.com/'


	def __get_page__(self, url, cacheTime=3600000):
		return api.SOUPKit(cache_path=self.cache_path).SOUPFromURL(url, cacheTime=cacheTime)


	def base_url(self):
		return self.base_url


	def menu(self):
		page = self.__get_page__(self.base_url)
		menu = {}

		content = page.find('div', {'id': 'menu-fixed'})
		for a in content.find_all('a'):
			menu[unicode(a.text)] = self.base_url + a['href']

		content = page.find('div', {'id': 'menu'})
		for ul in content.find('ul'):
			title = ul.find('p')
			if title <> None and title != -1:
				title = unicode(title.text)
				sub_menu = []
				for a in ul.find_all('a'):
					sub_menu.append({'href': self.base_url + a['href'], 'label': unicode(a['title'])})
				menu[title] = sub_menu
		return menu


	def contents(self, url):
		page = self.__get_page__(url)
		items = []
		ul = page.find('ul', {'class': 'list_m list_6'})
		for c in ul.find_all('a'):
			href = self.base_url + c['href']
			title = unicode(c['title'])
			title = title.split('-')
			title1 = title[0].strip()
			title2 = title[1].strip()

			poster = c.find('img', {'class': 'lazy'})['data-original']
			duration = c.find('span', {'class': 'ep'})
			if duration <> None and duration <> -1:
				duration = duration.text
			else:
				duration = ''
			items.append({'title1': unicode(title1), 'title2': unicode(title2), 'href': href, 'duration': unicode(duration), 'info': unicode(duration), 'poster': poster})


		next_page = self.__next_page__(page)
		return {'items': items, 'next_page': next_page}


	def media_items(self, url):
		page = self.__get_page__(url)

		poster = page.find('link', {'rel': 'image_src'})['href']
		title = page.find('span', {'class': 'fn'}).text
		title = title.split('-')
		title1 = title[0].strip()
		title2 = title[1].strip()

		#find button
		btn = self.base_url + page.find('a', {'class': 'bt_xemphim'})['href']
		page = self.__get_page__(btn)

		media_items = {}
		for s in page.find_all('p', {'class': 'epi'}):
			server_name = s.find('b').text.replace('- ', '')
			server_name = unicode(server_name)
			for a in s.find_all('a'):
				href = self.base_url + a['href']
				ep_title = u''.join([u'Tập ', a.text])
				s = []
				if ep_title in media_items:
					s = media_items[unicode(ep_title)]
				s.append({'title1': unicode(title1), 'title2': unicode(title2), 'ep_title': ep_title, 'poster': poster, 'banner': '', 'server_name': unicode(server_name), 'href': href})
				media_items[unicode(ep_title)] = s

		if media_items == {}:
			media_items[u'DEFAULT'] = [{'title1': unicode(title1), 'title2': unicode(title2), 'ep_title': '', 'poster': poster, 'banner': '', 'server_name': unicode('Server 1'), 'href': url}]
		return media_items


	def search(self, query):
		query = re.sub('\\s+', '-', query)
		search_url = self.base_url + 'tim-kiem/tat-ca/' + query + '.html'
		return self.contents(search_url)


	def __next_page__(self, page):
		pages = page.find('div', {'class': 'paging'})
		if pages is None:
			return None

		a = pages.find_all('a')

		if a is None:
			return None
		return self.base_url + a[len(a) - 1]['href']


	def resolve_stream(self, url):
		page = self.__get_page__(url)
		videos = None
		for s in page.find_all('script'):
			if 'sources' in s.text:
				m = re.search('(?i)sources:\s+(.*?)\)(?:,};)?', s.text)
				m = m.group(1)
				m = m[0:m.index(']')+1]
				m = m.replace('file', '"file"').replace('label', '"label"').replace('type', '"type"')
				m = eval(m)
				videos = m
				break
		rate = 0
		url = None
		if videos <> None:
			for v in videos:
				if 'type' in v and 'video/mp4' == v['type']:
					l = v['label'].replace('p', '')
					if l == '':
						l = '1'
					l = int(l)
					if l >= rate:
						rate = l
						url = v['file']
		if url <> None and url <> '':
			return url
		return None

