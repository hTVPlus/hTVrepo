#!/usr/bin/env python
# -*- coding: utf-8 -*-

import addon
import time

time.sleep(15)
addon.startChannel()
