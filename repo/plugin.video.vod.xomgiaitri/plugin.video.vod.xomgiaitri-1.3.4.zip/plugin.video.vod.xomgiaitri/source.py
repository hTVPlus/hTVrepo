# -*- coding: utf-8 -*-

import api
import urllib
from bs4 import element


class Source:
	def __init__(self, cache_path):
		self.cache_path = cache_path
		self.base_url = 'http://www.xom60.com/xem/'


	def __get_page__(self, url, cacheTime=3600000):
		return api.SOUPKit(cache_path=self.cache_path).SOUPFromURL(url, cacheTime=cacheTime)


	def base_url(self):
		return self.base_url


	def menu(self):
		page = self.__get_page__(self.base_url)
		menu = {}
		content = page.find('ul', {'id': 'thicktabs'})

		for li in content.children:
			if type(li) == element.Tag:
				a = li.find('a')
				label = a.text

				href = a['href']
				if './' == href or 'rss.php' == href or 'xomtinmoi' in href:
					continue
				menu[unicode(label)] = self.base_url + href

		table = page.find('table', {'class': 'border_menu'})
		top_menu = table.find_all('td', {'class': 'top_menu_1'})
		content_menu = table.find_all('td', {'class': 'content_menu_1'})

		for i, v in enumerate(top_menu):
			label = v.text.strip()
			if label == u'Phim Bộ':
				label = u'Quốc Gia'
			if label == u'Phim Lẻ':
				label = u'Thể Loại'

			sm = []
			for sub in content_menu[i].find_all('a'):
				if 'xomthugianvn' in sub['href']:
					continue
				sm.append({'href': self.base_url + sub['href'], 'label': unicode(sub.text.strip())})
			menu[unicode(label)] = sm
		return menu


	def contents(self, url):
		page = self.__get_page__(url)
		items = []
		duplicates = []

		for td in page.find_all('td', {'class': 'content_menu_1'}):
			table = td.find('table', {'align': 'center'})
			if table <> None:
				a = table.find('a')
				href = self.base_url + a['href']
				poster = a.find('img')['src']
				title = a['title'].strip()
				title1 = title
				duration = ''
				if '[' in title:
					duration = title[title.index('[') + 1: title.index(']')].strip()
					title1 = title[:title.index('[')].strip()

				if not href in duplicates:
					duplicates.append(href)
					items.append({'title1': unicode(title1), 'title2': '', 'href': href, 'duration': unicode(duration), 'info': '', 'poster': poster})


		next_page = self.__next_page__(page)
		return {'items': items, 'next_page': next_page}


	def media_items(self, url):
		page = self.__get_page__(url)
		poster = None
		banner = None

		info = page.find('table', {'class': 'tbl'}).find('a')
		poster = info.find('img')['src']

		title = page.find('div', {'class': 'info_film'}).find('p').find('span').text
		title = title.split('-')
		title1 = title[0].strip()
		try:
			title2 = title[1].strip()
		except:
			title2 = ''

		xem = page.find('p', {'class': 'w_now'}).find('a')['href']
		page = self.__get_page__(xem)

		media_items = {}
		for servers in page.find_all('div', {'class': 'listserver'}):
			name = servers.find('span', {'class': 'name'}).text.replace(':', '').strip()
			#ep1
			ep = servers.find('font', {'class': 'episode_bg_2'})
			if ep <> None:
				ep_title = u''.join([u'Tập ', ep.text.strip()])
				media_items[unicode(ep_title)] = [{'title1': unicode(title1), 'title2': unicode(title2), 'ep_title': ep_title, 'poster': poster, 'banner': '', 'server_name': unicode(name), 'href': xem}]

			for e in servers.find_all('a'):
				ep_title = e.text.strip()
				ep_title = ep_title.replace('\r', '').replace('\n', '')
				ep_title = u''.join([u'Tập ', ep_title])
				href = self.base_url + e['href']
				s = []
				if ep_title in media_items:
					s = media_items[unicode(ep_title)]
				s.append({'title1': unicode(title1), 'title2': unicode(title2), 'ep_title': ep_title, 'poster': poster, 'banner': banner, 'server_name': unicode(name), 'href': href})
				media_items[unicode(ep_title)] = s

		if media_items == {}:
			media_items['DEFAULT'] = [{'title1': unicode(title1), 'title2': unicode(title2), 'ep_title': '', 'poster': poster, 'banner': banner, 'server_name': unicode('Server 1'), 'href': xem}]
		return media_items


	def search(self, query):
		search_url = self.base_url + 'search/' + urllib.quote(query)
		return self.contents(search_url)


	def __next_page__(self, page):
		current = page.find('a', {'class': 'pagecurrent'})
		if current == None:
			return None

		current = current.parent
		pages = current.find_all('a')
		for i, p in enumerate(pages):
			if p['class'][0] == 'pagecurrent':
				if i+1 < len(pages):
					return self.base_url + pages[i+1]['href']

		return None


	def resolve_stream(self, url):
		page = self.__get_page__(url)
		src = page.find('source')['src']
		return src


